# Lab10_API_Calls
Lab 10 for Fundamentals of JavaScript | API Calls in JavaScript
